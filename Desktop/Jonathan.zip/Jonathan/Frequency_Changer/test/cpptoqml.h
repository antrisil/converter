#ifndef CPPTOQML_H
#define CPPTOQML_H


class cpptoqml
{
public:
    cpptoqml();
    void toQml();
};

#endif // CPPTOQML_H
