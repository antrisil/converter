#include "cpptoqml.h"
#include "pcan.h"
pcan *pcan1 = new pcan();

cpptoqml::cpptoqml()
{

}

void cpptoqml :: toQml(){
    QQuickView view;
    while(1){
        QQmlContext* context = view.engine()->rootContext();
        context->setContextProperty("Vin1", pcan1->getAB());
    }

}
