#include <includes.h>
#include <dbmanager.h>
#include <pcan.h>

//constructors
DbManager *db = new DbManager();
pcan *pcan0 = new pcan();

//methods to main
void dbmanager(){
    sleep(1);
    db->insertss();
    db->def_settings();
    db->create();
    db->keep100rows();
    db->droping();
    db->insertInto(pcan0);
}

void pcani(){
    QString errorString;
    can_do_stop("can0");
    can_set_bitrate("can0", 250000);
    can_do_start("can0");
    QCanBusDevice *device = QCanBus::instance()->createDevice(QStringLiteral("socketcan"), QStringLiteral("can0"), &errorString);
    if (!device){
        qDebug() << errorString;
        qDebug() << "error";
    }
    else {
        qDebug() << "all good";
        device->setConfigurationParameter(QCanBusDevice::BitRateKey, QVariant::fromValue(250000));
        device->connectDevice();
        pcan0->write(device);
        pcan0->receive(device);
    }
}

int main(int argc, char *argv[])
{
//  Threads
    QtConcurrent::run(pcani);
    QtConcurrent::run(dbmanager);

// Qt Charts uses Qt Graphics View Framework for drawing, therefore QApplication must be used.
    QApplication app(argc, argv);
    QQuickView viewer;
        viewer.engine()->rootContext()->setContextProperty("pcan", pcan0);
        viewer.setSource(QUrl::fromLocalFile("MONITOR.qml"));

// The following are needed to make examples run without having to install the module
// in desktop environments.
#ifdef Q_OS_WIN
    QString extraImportPath(QStringLiteral("%1/../../../../%2"));
#else
    QString extraImportPath(QStringLiteral("%1/../../../%2"));
#endif
    viewer.engine()->addImportPath(extraImportPath.arg(QGuiApplication::applicationDirPath(),
                                      QString::fromLatin1("qml")));
    QObject::connect(viewer.engine(), &QQmlEngine::quit, &viewer, &QWindow::close);

    viewer.setTitle(QStringLiteral("Test"));
    viewer.setSource(QUrl("qrc:/test/main.qml"));
    viewer.setProperty("width", 640);
    viewer.setProperty("height", 480);
    viewer.setResizeMode(QQuickView::SizeRootObjectToView);
    viewer.show();

    return app.exec();
}
