#ifndef DBMANAGER_H
#define DBMANAGER_H
#include <includes.h>
#include "pcan.h"

class DbManager
{
public slots:
    DbManager();
    void def_settings();
    void create();
    void keep100rows();
    void insertss();
    void droping();
    void insertInto(pcan *pcan0);

signals:
    void DBChanged();

private:
    QSqlDatabase m_db;
};

#endif // DBMANAGER_H
